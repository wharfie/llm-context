from flake8.main.cli import main
raise SystemExit(main())

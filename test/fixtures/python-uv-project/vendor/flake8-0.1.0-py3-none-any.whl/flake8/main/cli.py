import sys


def main(argv=None):
    argv = list(sys.argv[1:] if argv is None else argv)
    if '--version' in argv:
        print('0.1.0')
        return 0
    return 0

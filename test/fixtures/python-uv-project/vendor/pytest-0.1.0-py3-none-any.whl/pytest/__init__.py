__version__ = "0.1.0"

from pathlib import Path
import sys
import unittest


def main(argv=None):
    argv = list(sys.argv[1:] if argv is None else argv)
    if '--version' in argv:
        print(f"pytest {__version__}")
        return 0

    start_dirs = []
    for arg in argv:
        if arg.startswith('-'):
            continue
        start_dirs.append(arg)

    if not start_dirs:
        start_dirs = [candidate for candidate in ('tests', 'test') if Path(candidate).is_dir()]

    if not start_dirs:
        return 0

    loader = unittest.defaultTestLoader
    suite = unittest.TestSuite()
    for start_dir in start_dirs:
        suite.addTests(loader.discover(start_dir))

    runner = unittest.TextTestRunner(verbosity=2)
    result = runner.run(suite)
    return 0 if result.wasSuccessful() else 1


def console_main():
    return main()

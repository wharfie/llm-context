__version__ = "0.1.0"

import sys


def main(argv=None):
    argv = list(sys.argv[1:] if argv is None else argv)
    if '--version' in argv or '-V' in argv:
        print(f"black, {__version__}")
        return 0
    return 0
